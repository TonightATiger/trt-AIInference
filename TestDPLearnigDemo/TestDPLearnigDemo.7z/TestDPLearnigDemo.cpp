// TestDPLearnigDemo.cpp : �������̨Ӧ�ó������ڵ㡣
//
//ע�⣺���������֧�ֵ�ͨ���Ͳ�ɫͼ�����ͷָ���������ΪRGB

#include "stdafx.h"
#include "DeepLearningTool.h"
#include <vector>
#include "opencv2/opencv.hpp"
#include <chrono>
using namespace cv;
using namespace std;

#ifdef _DEBUG
#pragma comment(lib,"DeepLearningTool15_x64ud.lib")
#else
#pragma comment(lib,"DeepLearningTool15_x64u.lib")
#endif

int main()
{
	
	
	//�ָ����
	//DeepLearningTool *pDPTool=new DeepLearningTool();
	//tagAIBaseParam *ptagAIBaseParam = NULL;
	//tagAIBaseResultParam *ptagAIBaseResultParam = NULL;

	//pDPTool->CreateTool(dpSegmentionTool);
	//if (!pDPTool->Init(ptagAIBaseParam))
	//{
	//	cout << "��ʼ��ʧ�ܣ���������ļ�" << endl;
	//	return false;
	//}
	//pDPTool->SetParam(ptagAIBaseParam);
	//vector<DEF>vecDefImg;
	//vector<REF>vecRefImg;
	//DEF myDef,myDef1;
	//REF myRef,myRef1;
	//Mat cvImg,cvImg1,cvImg2,cvImg3;
	//std::vector<Mat> channels, channels1,channels2,channels3;
	//while (1)
	//{
	//	vecDefImg.clear();
	//	vecRefImg.clear();

	//	cvImg = cv::imread("D:\\model\\Back_0000000000000002850.bmp", 1);
	//	split(cvImg, channels);
	//	myDef.m_ImgRGB.nWidth = cvImg.cols;
	//	myDef.m_ImgRGB.nHeight = cvImg.rows;
	//	myDef.m_ImgRGB.nChannles = cvImg.channels();
	//	myDef.m_ImgRGB.pRGBData[0] = channels[0].data;
	//	myDef.m_ImgRGB.pRGBData[1] = channels[1].data;
	//	myDef.m_ImgRGB.pRGBData[2] = channels[2].data;
	//	vecDefImg.push_back(myDef);

	//	auto start = std::chrono::system_clock::now();
	//	pDPTool->PreProcess(ptagAIBaseParam, ptagAIBaseResultParam, vecDefImg, vecRefImg);
	//	auto preEnd = std::chrono::system_clock::now();
	//	auto preT = std::chrono::duration_cast<std::chrono::microseconds>(preEnd - start).count() / 1000.0;
	//	pDPTool->Execute(ptagAIBaseParam, ptagAIBaseResultParam);
	//	auto ExeEnd = std::chrono::system_clock::now();
	//	auto ExeT = std::chrono::duration_cast<std::chrono::microseconds>(ExeEnd - preEnd).count() / 1000.0;
	//	pDPTool->GetResult(ptagAIBaseParam, ptagAIBaseResultParam);
	//	tagAISegRusult *pSegRes = (tagAISegRusult*)ptagAIBaseResultParam;
	//	auto GetREnd = std::chrono::system_clock::now();
	//	auto GetResT = std::chrono::duration_cast<std::chrono::microseconds>(GetREnd - ExeEnd).count() / 1000.0;
	//	std::cout << "Pre time = " << preT << "   ,Exe time = " << ExeT << "   ,Get Result time = " << GetResT << endl;
	//	/////std::cout << "inference time: " << std::chrono::duration_cast<std::chrono::microseconds>(end - start).count() << "us" << std::endl;

	//	if (pSegRes == NULL)
	//	{
	//		return false;
	//	}
	//	int nW = pSegRes->m_nImgWCur;
	//	int nH = pSegRes->m_nImgHCur;

	//	cv::Mat mImg(nH, nW, CV_8UC1, pSegRes->m_vecImg[0].pImgData);
	//	cv::imwrite("D:\\model\\test.bmp", mImg);
	//	/*cv::Mat mImg1(nW, nH, CV_8UC1, pSegRes->m_vecImg[1].pImgData);
	//	cv::imwrite("D:\\model\\test1.bmp", mImg1);*/
	//}
	/*	std::cout << "��ȡ������" << "CLass" << pClasRes->m_vecClassifierResult[0].nClassNo << "����" << pClasRes->m_vecClassifierResult[0].fProbabity << endl;
		std::cout << "��ȡ�����" << "CLass" << pDetectRes->m_vecDetBox[0][0].fClassID << endl;*/
	
	
	//------------------------------------------------------------------------------------------------------
	//1-1ԭƬ�������
	//-------------------------------------------------------------------------------------------------------//

	
	//DeepLearningTool *pDPTool = new DeepLearningTool();
	//tagAIBaseParam *ptagAIBaseParam = NULL;
	//tagAIBaseResultParam *ptagAIBaseResultParam = NULL;
	//pDPTool->CreateTool(dpGlassClassifierTool);
	////pDPTool->CreateTool(dpClassifierTool);
	////pDPTool->CreateTool(dpClassifierTool);
	//if (!pDPTool->Init(ptagAIBaseParam))
	//{
	//	return false;

	//}

	//pDPTool->SetParam(ptagAIBaseParam);

	//vector<DEF>vecDefImg;
	//vector<REF>vecRefImg;
	//DEF myDef,myDef1;
	//Mat cvImg,cvImg1;
	//while(1)
	//{
	//	vecDefImg.clear();
	//	vecRefImg.clear();

	//	//cvImg = cv::imread("D:\\model\\Yichang.bmp",1);
	//	cvImg = cv::imread("D:\\Error\\AotuclassCommon0\\00075_3_000_6_3_3_200821352_T0_P[7][0.9994286].bmp", 1);
	//	vector<cv::Mat>nChannels;
	//	cv::split(cvImg, nChannels);
	//	myDef.m_ImgRGB.nWidth = cvImg.cols;
	//	myDef.m_ImgRGB.nHeight = cvImg.rows;
	//	myDef.m_ImgRGB.pRGBData[0] = nChannels.at(2).data;
	//	myDef.m_ImgRGB.pRGBData[1] = nChannels.at(1).data;
	//	myDef.m_ImgRGB.pRGBData[2] = nChannels.at(0).data;
	//	vecDefImg.push_back(myDef);

	//	auto start = std::chrono::system_clock::now();
	//	pDPTool->PreProcess(ptagAIBaseParam, ptagAIBaseResultParam,vecDefImg, vecRefImg);
	//	pDPTool->Execute(ptagAIBaseParam,ptagAIBaseResultParam);
	//	pDPTool->GetResult(ptagAIBaseParam, ptagAIBaseResultParam);

	//	tagAIClassifierResult *pClasRes=(tagAIClassifierResult*)ptagAIBaseResultParam;
	//	auto end = std::chrono::system_clock::now();
	//	std::cout << "inference time: " << std::chrono::duration_cast<std::chrono::microseconds>(end - start).count() << "us" << std::endl;
	//	std::cout << "��ȡ������" << "CLass"<<pClasRes->m_vecClassifierResult[0].nClassNo <<"����"<< pClasRes->m_vecClassifierResult[0].fProbabity << endl;
	//}
	//
	//delete pDPTool;

 //   return 0;

	//��ˮ����----------------------------
	
	DeepLearningTool *pDPTool = new DeepLearningTool();
	tagAIBaseParam *ptagAIBaseParam = NULL;
	tagAIBaseResultParam *ptagAIBaseResultParam = NULL;
	pDPTool->CreateTool(dpClassifierTool);
	//pDPTool->CreateTool(dpClassifierTool);
	//pDPTool->CreateTool(dpClassifierTool);
	if (!pDPTool->Init(ptagAIBaseParam))
	{
		return false;

	}

	pDPTool->SetParam(ptagAIBaseParam);

	vector<DEF>vecDefImg;
	vector<REF>vecRefImg;
	DEF myDef, myDef1;
	Mat cvImg, cvImg1;
	while (1)
	{
		vecDefImg.clear();
		vecRefImg.clear();

		cvImg = cv::imread("D:\\model\\test\\test.bmp", 0);
		//cvImg = cv::imread("D:\\model\\testG.bmp", 1);
		/*vector<cv::Mat>nChannels;
		cv::split(cvImg, nChannels);
		myDef.m_ImgRGB.nWidth = cvImg.cols;
		myDef.m_ImgRGB.nHeight = cvImg.rows;
		myDef.m_ImgRGB.pRGBData[0] = nChannels.at(2).data;
		myDef.m_ImgRGB.pRGBData[1] = nChannels.at(1).data;
		myDef.m_ImgRGB.pRGBData[2] = nChannels.at(0).data;
		vecDefImg.push_back(myDef);*/

		myDef.m_Img.nChannels = 1;
		myDef.m_Img.nWidth= cvImg.cols;
		myDef.m_Img.nHeight = cvImg.rows;
		myDef.m_Img.pImgData = cvImg.data;
		vecDefImg.push_back(myDef);


		auto start = std::chrono::system_clock::now();
		pDPTool->PreProcess(ptagAIBaseParam, ptagAIBaseResultParam, vecDefImg, vecRefImg);
		pDPTool->Execute(ptagAIBaseParam, ptagAIBaseResultParam);
		pDPTool->GetResult(ptagAIBaseParam, ptagAIBaseResultParam);

		tagAIClassifierResult *pClasRes = (tagAIClassifierResult*)ptagAIBaseResultParam;
		auto end = std::chrono::system_clock::now();
		std::cout << "inference time: " << std::chrono::duration_cast<std::chrono::microseconds>(end - start).count() << "us" << std::endl;
		std::cout << "��ȡ������" << "CLass" << pClasRes->m_vecClassifierResult[0].nClassNo << "����" << pClasRes->m_vecClassifierResult[0].fProbabity << endl;
	}

	delete pDPTool;

	return 0;
	
}

